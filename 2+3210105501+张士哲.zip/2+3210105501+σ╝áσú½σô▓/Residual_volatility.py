import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

class ResidualVolatilityCalculator:
    def __init__(self, half_life=63, window=252):
        """
        初始化 ResidualVolatilityCalculator。

        参数:
        - half_life: int，指数权重的半衰期（默认 63 个交易日）。
        - window: int，回归窗口大小（默认 252 个交易日）。
        """
        self.half_life = half_life
        self.window = window
        
    def stock_return(self):
        self.stock = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/daily_quote_2010_2018_combined.csv')
        self.stock['TradingDay'] = pd.to_datetime(self.stock['TradingDay'])
        self.stock.set_index('TradingDay', inplace=True)
        
        stock_returns_df = self.stock.pivot_table(values='ret', index=self.stock.index, columns='SecuCode')
        return stock_returns_df

    def market_return(self):
        """
        读取市场收益率数据，并返回市场收益率的 DataFrame。
        """
        self.market = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/daily_quote_2010_2018_combined.csv')
        self.market['TradingDay'] = pd.to_datetime(self.market['TradingDay'])
        self.market.set_index('TradingDay', inplace=True)

        market_returns_df = self.market.pivot_table(values='ZZ500Ret', index=self.market.index, columns='SecuCode')
        self.index = market_returns_df.index
        self.columns = market_returns_df.columns
        return market_returns_df

    def get_risk_free_rates(self, rate=0.0001):
        """
        获取无风险收益率（近似十年国债利率）
        """
        return pd.DataFrame(rate, index=self.index, columns=self.columns)

    
    def calculate_dastd(self, stock_excess_returns):
        """计算 DASTD：日收益率的标准差"""
        lambda_ = np.log(2) / self.half_life
        weights = np.exp(-lambda_ * np.arange(self.window)[::-1])  # 指数权重
        weights /= weights.sum()  # 归一化权重

        dastd_df = pd.DataFrame(index=stock_excess_returns.index, columns=stock_excess_returns.columns)

        for stock in stock_excess_returns.columns:
            for i in range(self.window, len(stock_excess_returns)):
                returns_window = stock_excess_returns[stock].iloc[i - self.window:i]
                if np.isnan(returns_window).all():
                    dastd_df.at[stock_excess_returns.index[i], stock] = np.nan
                else:
                    weighted_std = np.sqrt(np.sum(weights * (returns_window - returns_window.mean())**2))
                    dastd_df.at[stock_excess_returns.index[i], stock] = weighted_std

        return dastd_df


    def calculate_cmra(self, stock_returns_df):
        """计算 CMRA：累积收益率的最大值和最小值的对数差"""
        cmra_df = pd.DataFrame(index=stock_returns_df.index, columns=stock_returns_df.columns)
        
        # 计算对数超额收益率
        stock_excess_returns = np.log1p(stock_returns_df) - np.log1p(risk_free_rates)
        
        for stock in stock_excess_returns.columns:
            for i in range(self.window, len(stock_excess_returns)):
                # 获取滚动窗口内的数据
                returns_window = stock_excess_returns[stock].iloc[i - self.window:i]

                # 检查是否有 NaN
                if np.isnan(returns_window).all():
                    cmra_df.at[stock_excess_returns.index[i], stock] = np.nan
                else:
                    # 计算每个21天周期的累积超额对数收益率，和文档中的算法可能略有不同
                    cumulative_log_returns = [np.log1p(returns_window[j:j+21]).sum() for j in range(0, len(returns_window), 21)]
                    cumulative_log_returns_sum = np.cumsum(cumulative_log_returns)
                    # 计算 CMRA
                    cmra = np.log1p(max(cumulative_log_returns_sum)) - np.log1p(min(cumulative_log_returns_sum))
                    cmra_df.at[stock_excess_returns.index[i], stock] = cmra

        return cmra_df
    
    def calculate_hsigma(self):
        """计算 HSIGMA：历史波动率"""
        lambda_ = np.log(2) / self.half_life
        weights = np.exp(-lambda_ * np.arange(self.window)[::-1])  # 指数权重
        weights /= weights.sum()  # 归一化权重
        
        residual_df = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/beta_residual.csv', index_col='TradingDay')
        residual_df.columns = residual_df.columns.astype(int)
        
        hsigma_df = pd.DataFrame(index=stock_excess_returns.index, columns=stock_excess_returns.columns)

        for stock in residual_df.columns:
            for i in range(self.window, len(residual_df)):
                # 获取滚动窗口内的数据
                residual_window = residual_df[stock].iloc[i - self.window:i]

                # 检查是否有 NaN
                if np.isnan(residual_window).all():
                    hsigma_df.at[residual_df.index[i], stock] = np.nan
                else:
                    # 计算加权历史波动率
                    weighted_std = np.sqrt(np.sum(weights * (residual_window - residual_window.mean())**2))
                    hsigma_df.at[residual_df.index[i], stock] = weighted_std

        return hsigma_df
    
    def combine_volatility(self, dastd_path, cmra_path, hsigma_path):
        """
        读取 DASTD, CMRA, HSIGMA 的 CSV 文件，并计算组合波动率。

        参数:
        - dastd_path: str，DASTD CSV 文件的路径。
        - cmra_path: str，CMRA CSV 文件的路径。
        - hsigma_path: str，HSIGMA CSV 文件的路径。

        返回:
        - combined_vol_df: DataFrame，组合波动率，index 和 columns 与输入保持一致。
        """
        # 读取 CSV 文件
        dastd_df = pd.read_csv(dastd_path, index_col='TradingDay')
        cmra_df = pd.read_csv(cmra_path, index_col='TradingDay')
        hsigma_df = pd.read_csv(hsigma_path, index_col='TradingDay')

        # 计算组合波动率
        combined_vol_df = 0.74 * dastd_df + 0.16 * cmra_df + 0.10 * hsigma_df

        return combined_vol_df
    
    def orthogonalize(self, factor_df, beta_df, size_df):
        """
        将因子与 Beta 和 Size 正交化，以减少共线性。

        参数:
        - factor_df: DataFrame，待正交化的因子。
        - beta_df: DataFrame，Beta 因子。
        - size_df: DataFrame，Size 因子。

        返回:
        - orthogonalized_factor_df: DataFrame，正交化后的因子。
        """
        orthogonalized_factor_df = pd.DataFrame(index=factor_df.index, columns=factor_df.columns)

        for date in factor_df.index:
            X = pd.concat([beta_df.loc[date], size_df.loc[date]], axis=1)
            y = factor_df.loc[date]
            X_1 = beta_df.loc[date].values.reshape(-1, 1)
            X_2 = size_df.loc[date].values.reshape(-1, 1)
            valid_idx = ~np.isnan(X_1.flatten()) & ~np.isnan(X_2.flatten()) & ~np.isnan(y)
            X_valid = X[valid_idx]
            y_valid = y[valid_idx]
            
            if len(X_valid) == 0:
                orthogonalized_factor_df.loc[date] = np.nan  # 该日期的残差设为 NaN
                continue

            if len(X_valid) > 0 and len(y_valid) > 0:
                model = LinearRegression()
                model.fit(X_valid, y_valid)
                residuals = y_valid - model.predict(X_valid)
                orthogonalized_factor_df.loc[date, residuals.index] = residuals

        return orthogonalized_factor_df
    
if __name__ == "__main__":
    # 初始化 ResidualVolatilityCalculator
    residual_vol_calculator = ResidualVolatilityCalculator(half_life=42, window=252)
    
    stock_returns_df = residual_vol_calculator.stock_return()
    market_returns_df = residual_vol_calculator.market_return()
    risk_free_rates = residual_vol_calculator.get_risk_free_rates()
    
    # 计算超额收益
    stock_excess_returns = stock_returns_df - risk_free_rates
    market_excess_returns = market_returns_df - risk_free_rates

    # 计算 DASTD
    dastd_df = residual_vol_calculator.calculate_dastd(stock_excess_returns)
    dastd_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/dastd.csv')

    # 计算 CMRA
    cmra_df = residual_vol_calculator.calculate_cmra(stock_returns_df)
    cmra_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/cmra.csv')

    # 计算 HSIGMA
    hsigma_calculator = ResidualVolatilityCalculator(half_life=63, window=252)
    hsigma_df = hsigma_calculator.calculate_hsigma()
    hsigma_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/hsigma.csv')
    
    combined_vol_df = residual_vol_calculator.combine_volatility(
        '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/dastd.csv',
        '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/cmra.csv',
        '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/hsigma.csv'
    )
    combined_vol_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/combined_volatility.csv')
    
    size_df = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/log_cap.csv', index_col='TradingDay')
    beta_df = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/beta.csv', index_col='TradingDay')
    
    orthogonalized_factor_df = residual_vol_calculator.orthogonalize(combined_vol_df, beta_df, size_df)
    orthogonalized_factor_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/residual_voli.csv')