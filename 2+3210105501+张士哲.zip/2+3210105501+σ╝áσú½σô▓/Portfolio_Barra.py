from Backtest import Analyze
from Backtest import Backtest_v3
from matplotlib import pyplot as plt
import pandas as pd
import numpy as np
import cvxpy as cp
from Regression import CrossSectionalRegression
from Barra import Sigma
import pickle
import os
from Regression import DataProcessor, read_factor_data
import time
from functools import wraps


data_processor = DataProcessor(limits=(0.01, 0.99))


def timing_decorator(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"Function '{func.__name__}' executed in {elapsed_time:.4f} seconds")
        return result
    return wrapper

class Portfolio(CrossSectionalRegression):
    def __init__(self, file_path, lambda_value=0.94, half_life=42, window=252):
        self.file_path = file_path
        self.lambda_value = lambda_value
        self.half_life = half_life
        self.window = window
        self.returns = self._load_data()
        self.weights = None

    def _load_data(self):
        """
        读取因子收益率数据
        """
        return pd.read_csv(self.file_path, index_col='TradingDay', parse_dates=True)

    def calculate_ewma_covariance(self, factor_returns):
        """
        计算因子收益率的EWMA协方差矩阵
        :param factor_returns: 因子收益率数据（DataFrame，index为日期，columns为因子名称）
        :return: EWMA协方差矩阵
        """
        dates = factor_returns.index
        factors = factor_returns.columns
        n_factors = len(factors)
        
        lambda_ = np.log(2) / self.half_life
        weights = np.exp(-lambda_ * np.arange(self.window)[::-1])  # 指数权重
        weights /= weights.sum()  # 归一化权重

        # 初始化第一个协方差矩阵
        cov_matrix = np.cov(factor_returns.iloc[:252].T)
        cov_matrix_series = {dates[251]: pd.DataFrame(cov_matrix, index=factors, columns=factors)}
        
        window_length = self.window
        # 遍历每个时间点
        for t in range(window_length, len(dates)):
            # 获取当前时间窗口的数据
            window_data = factor_returns.iloc[t - window_length:t]

            # 计算加权协方差矩阵
            weighted_cov_matrix = np.zeros((n_factors, n_factors))
            for s in range(window_length):
                f_t = window_data.iloc[s].values.reshape(-1, 1)
                weighted_cov_matrix += weights[s] * np.dot(f_t, f_t.T)
                
            weighted_cov_matrix = weighted_cov_matrix[:-1, :-1]  # 删除最后一列和最后一行
            # 保存协方差矩阵
            cov_matrix_series[dates[t]] = weighted_cov_matrix
        
        return cov_matrix_series

    def filter_cov_matrix(self, cov_matrix):
        """
        筛选协方差矩阵中没有 NaN 的行和列
        :param cov_matrix: 协方差矩阵（DataFrame）
        :return: 筛选后的协方差矩阵
        """
        # 筛选出没有 NaN 的行和列
        valid_indices = ~cov_matrix.isna().all(axis=1)
        filtered_cov_matrix = cov_matrix.loc[valid_indices, valid_indices]
        return filtered_cov_matrix
   
    def calculate_factor_covariance(self, factor_returns):
        """
        使用 Sigma 类计算因子收益率的EWMA协方差矩阵
        :param factor_returns: 因子收益率数据（DataFrame，index为日期，columns为因子名称）
        :return: EWMA协方差矩阵
        """
        cache_file = f'cache/factor_covariance_{self.lambda_value}_{self.half_life}_{self.window}.pkl'
        if os.path.exists(cache_file):
            with open(cache_file, 'rb') as f:
                cov_matrix_series = pickle.load(f)
        else:
            sigma = Sigma(lambda_value=self.lambda_value, half_life=self.half_life, window=self.window)
            cov_matrix_series = sigma.calculate_ewma_covariance(factor_returns)
            with open(cache_file, 'wb') as f:
                pickle.dump(cov_matrix_series, f)
        return cov_matrix_series
    
    @timing_decorator
    def barra_rebalancing(self, factor_exposures_files, specific_risk_matrix_file):
        """
        最小化风险暴露矩阵和因子协方差矩阵与特异性矩阵的总和
        :param factor_exposures_files: 因子暴露矩阵文件列表（每个文件包含一个因子暴露矩阵）
        :param factor_cov_matrix_file: 因子协方差矩阵文件
        :param specific_risk_matrix_file: 特异性矩阵文件
        :return: 最优权重（DataFrame，index为日期，columns为股票代码）
        """
        # 读取因子暴露矩阵
        factor_exposures_list = []
        for file in factor_exposures_files:
            factor_exposure = pd.read_csv(file, index_col='TradingDay', parse_dates=True)
            processed_df = data_processor.winsorize_and_standardize(factor_exposure)
            factor_exposures_list.append(processed_df)
            
        # 读取因子协方差矩阵
        factor_returns = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/return_results_filtered.csv', index_col=0, parse_dates=True)
        cov_matrix_series = self.calculate_factor_covariance(factor_returns)
        # 读取特异性矩阵
        specific_risk_matrix = pd.read_csv(specific_risk_matrix_file, index_col=0, parse_dates=True)

        monthly_portfolios = {}
        # 获取每个月的最后一个交易日
        last_days = self.returns.groupby(self.returns.index.to_period('M')).apply(lambda x: x.index[-1])
        for end_of_month in last_days:
            if end_of_month.year < 2013:
                continue
            
            factor_exposures_list_current = []
            for file in factor_exposures_list:
                factor_exposure = file.loc[end_of_month]
                factor_exposures_list_current.append(factor_exposure)
            current_factor_exposures = pd.concat(factor_exposures_list_current, axis=1)
            current_factor_exposures = filter_bank(current_factor_exposures,iorc='row')
            
            # 和行业因子拼接在一起
            industry_dummy = pd.get_dummies(self.industry_df.loc[end_of_month]).astype(int)
            current_factor_exposures = pd.concat([current_factor_exposures, industry_dummy], axis=1)

            # 获取当前时间点的因子协方差矩阵
            if end_of_month in cov_matrix_series:
                current_factor_cov_matrix = pd.DataFrame(cov_matrix_series[end_of_month])
            else:
                print(f"Warning: {end_of_month} not found in cov_matrix_series")
                continue

            # 获取当前时间点的特异性矩阵
            current_specific_risk_matrix = specific_risk_matrix.loc[end_of_month]
            diag = pd.DataFrame(np.diag(current_specific_risk_matrix.values))

            # 筛选出没有 NaN 的行和列
            mask_1 = (current_factor_exposures.isna() | (current_factor_exposures == 0)).all(axis=1)
            current_factor_exposures = current_factor_exposures[~mask_1]
            
            current_specific_risk_matrix = current_specific_risk_matrix.to_frame()
            mask_2 = (current_specific_risk_matrix.isna() | np.isclose(current_specific_risk_matrix, 0)).all(axis=1)
            current_specific_risk_matrix = current_specific_risk_matrix[~mask_2]
            current_factor_exposures = current_factor_exposures.dropna()
            # current_factor_exposures = self.filter_cov_matrix(current_factor_exposures)
            # current_specific_risk_matrix = self.filter_cov_matrix(current_specific_risk_matrix)
            
            common_stocks = current_factor_exposures.index.intersection(current_specific_risk_matrix.index).intersection(current_specific_risk_matrix.index)
            current_factor_exposures = current_factor_exposures.loc[common_stocks]
            # current_factor_exposures = current_factor_exposures.drop(current_factor_exposures.columns[-1], axis=1)
            current_specific_risk_matrix = current_specific_risk_matrix.loc[common_stocks]
            
            # 检查输入数据是否有 NaN 或 Inf 值
            if current_factor_exposures.isna().any().any() or np.isnan(current_specific_risk_matrix.values).any() or np.isinf(current_specific_risk_matrix.values).any():
                print(f"NaN or Inf values found in input data for {end_of_month}")
                continue

            # 检查数据维度是否匹配
            if current_factor_exposures.shape[0] == 0 or current_specific_risk_matrix.shape[0] == 0:
                print(f"No valid data for {end_of_month}")
                continue

            # 确保因子暴露矩阵和因子协方差矩阵的列数匹配
            if current_factor_exposures.shape[1] != current_factor_cov_matrix.shape[0]:
                print(f"Dimension mismatch between factor exposures and factor covariance matrix for {end_of_month}")
                continue
            
            # 定义优化变量
            stocks = current_factor_exposures.index
            n_stocks = len(stocks)
            weights = cp.Variable(n_stocks)
            
            # 计算因子风险
            factor_risk = cp.quad_form(weights @ current_factor_exposures.values, current_factor_cov_matrix.values)

            # 计算特异性风险
            specific_risk = cp.quad_form(weights, np.diag(current_specific_risk_matrix.values.flatten()))
            # specific_risk = cp.quad_form(weights, np.diag(current_specific_risk_matrix.values))
            # specific_risk = cp.quad_form(weights, current_specific_risk_matrix.values)

            # 定义目标函数（最小化总风险）
            total_risk = factor_risk + specific_risk
            objective = cp.Minimize(total_risk)

            # 定义约束条件
            constraints = [
                cp.sum(weights) == 1,  # 权重之和为1
                weights >= 0,  # 权重非负
                weights <= 0.01  # 单只股票权重不超过0.01
            ]

            # 定义并求解优化问题
            prob = cp.Problem(objective, constraints)
            prob.solve()

            # 获取最优权重
            optimal_weights = weights.value

            # 将最优权重映射回原始股票
            optimal_weights_series = pd.Series(optimal_weights, index=stocks)

            monthly_portfolios[end_of_month] = optimal_weights_series
            print(optimal_weights_series)
            print('Optimal weights for', end_of_month, 'have been calculated.')

        # 转换为 DataFrame
        self.weights = pd.DataFrame.from_dict(monthly_portfolios, orient='index', columns=self.returns.columns)
        self.weights.index = pd.to_datetime(self.weights.index)
        self.weights.columns = self.weights.columns.astype(int)
        return self.weights
    
    def backtest(self, price_data, commission=0.003):
        """
        进行回测计算
        """
        if self.weights is None:
            raise ValueError("请先计算月度调仓权重")

        # 调用 Backtest_v3 函数进行回测
        nv_no_fee, nv_no_fee_prod = Backtest_v3(self.weights, price_data, commission)

        return nv_no_fee, nv_no_fee_prod
    
def filter_bank(df,iorc):
    """
    过滤掉列名为 601128 和 600908 的列
    :param df: 输入的 DataFrame
    :return: 过滤后的 DataFrame
    """
    if iorc == 'column':
        exclude_stocks = ['601128', '600908',601128,600908]
        return df.drop(columns=exclude_stocks, errors='ignore')
    elif iorc == 'row':
        exclude_stocks = ['601128', '600908',601128,600908]
        return df.drop(index=exclude_stocks, errors='ignore')
        
# 示例用法
if __name__ == "__main__":
    file_path = '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/ret.csv'
    portfolio_barra = Portfolio(file_path)

    # 因子暴露矩阵文件列表
    factor_exposures_files = [
        '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/liquidity.csv',
        '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/beta.csv',
        '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/log_cap.csv',
        '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/residual_voli.csv',
        '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/tri_cap.csv',
        '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/momentum.csv',
    ]

    industry_df = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/industry_factors_numbered.csv', index_col=0, parse_dates=True)
    portfolio_barra.industry_df = filter_bank(industry_df,iorc='column')

    # 特异性矩阵文件
    specific_risk_matrix_file = '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/specific_risk_matrices.csv'

    # 计算最优权重
    weights = portfolio_barra.barra_rebalancing(factor_exposures_files, specific_risk_matrix_file)
    
        # 读取股票价格数据
    quote= pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/daily_quote_2010_2018_combined.csv')
    price_data = quote.pivot_table(values='ClosePrice', index=quote['TradingDay'], columns='SecuCode')
    price_data.index = pd.to_datetime(price_data.index)

    # 进行回测计算
    nv_no_fee, nv_no_fee_prod = portfolio_barra.backtest(price_data)
    
    # 除去最后的数据点
    nv_no_fee = nv_no_fee[:-2]
    nv_no_fee_prod = nv_no_fee_prod[:-2]

     
    # # 绘制净值曲线
    # plt.figure(figsize=(10, 6))
    # plt.plot(nv_no_fee, label='Sum Net Value (No Fee)(Barra)')
    # plt.xlabel('Date')
    # plt.ylabel('Net Value')
    # plt.title('Net Value Over Time(Barra)')
    # plt.legend()
    # plt.grid(True)
    # plt.savefig('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/graph/Barra_Sum_Return_Rebalancing.png')
    
    # 绘制净值曲线 （累乘）
    plt.figure(figsize=(10, 6))
    plt.plot(nv_no_fee_prod-1, label='Compound Net Value (No Fee)(Barra)')
    plt.xlabel('Date')
    plt.ylabel('Net Value')
    plt.title('Compound Net Value Over Time(Barra)')
    plt.legend()
    plt.grid(True)
    plt.savefig('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/graph/Barra_Compound_Return_Rebalancing.png')