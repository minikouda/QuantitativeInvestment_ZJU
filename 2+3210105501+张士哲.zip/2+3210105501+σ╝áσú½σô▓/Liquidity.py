import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

class LiquidityCalculator:
    def __init__(self, window_stom=21, window_stoq=63, window_stoa=252):
        self.window_stom = window_stom  # 21 个交易日（约 1 个月）
        self.window_stoq = window_stoq  # 63 个交易日（约 3 个月）
        self.window_stoa = window_stoa  # 252 个交易日（约 12 个月）
        
    def stock_turnover(self):
        self.stock = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/daily_quote_2010_2018_combined.csv')
        self.stock['TradingDay'] = pd.to_datetime(self.stock['TradingDay'])
        self.stock.set_index('TradingDay', inplace=True)

        # 计算每日换手率
        self.stock['Turnover'] = self.stock['TradingVolumes'] / self.stock['AFloats']
        return self.stock


    def calculate_stom(self):
        """计算 STOM 因子"""
        # 读取数据

        liquidity_df = self.stock.pivot_table(values='Turnover', index= self.stock.index, columns='SecuCode')
        # 初始化结果 DataFrame
        stom_df = pd.DataFrame(index=liquidity_df.index, columns=liquidity_df.columns)

        for stock in liquidity_df.columns:
            for i in range(self.window_stom, len(liquidity_df)):
                # 获取滚动窗口内的数据
                turnover_window = liquidity_df[stock].iloc[i - self.window_stom:i]

                # 检查是否有 NaN
                if np.isnan(turnover_window).all():
                    stom_df.at[liquidity_df.index[i], stock] = np.nan
                else:
                    # 计算一个月的换手率
                    stom = np.log(turnover_window.sum())
                    stom_df.at[liquidity_df.index[i], stock] = stom

        return stom_df
    
    def calculate_stoq(self):
        """计算 STOQ 因子（季度换手率）"""
        # 读取数据
        liquidity_df = self.stock.pivot_table(values='Turnover', index=self.stock.index, columns='SecuCode')
        
        # 初始化结果 DataFrame
        stoq_df = pd.DataFrame(index=liquidity_df.index, columns=liquidity_df.columns)

        for stock in liquidity_df.columns:
            for i in range(self.window_stoq, len(liquidity_df)):
                # 获取滚动窗口内的数据
                turnover_window = liquidity_df[stock].iloc[i - self.window_stoq:i]

                # 检查是否有 NaN
                if np.isnan(turnover_window).all():
                    stoq_df.at[liquidity_df.index[i], stock] = np.nan
                else:
                    # 计算一个季度的换手率
                    stoq = np.log(turnover_window.sum() / 3)
                    stoq_df.at[liquidity_df.index[i], stock] = stoq

        return stoq_df

    def calculate_stoa(self):
        """计算 STOA 因子（年度换手率）"""
        # 读取数据
        liquidity_df = self.stock.pivot_table(values='Turnover', index=self.stock.index, columns='SecuCode')
        
        # 初始化结果 DataFrame
        stoa_df = pd.DataFrame(index=liquidity_df.index, columns=liquidity_df.columns)

        for stock in liquidity_df.columns:
            for i in range(self.window_stoa, len(liquidity_df)):
                # 获取滚动窗口内的数据
                turnover_window = liquidity_df[stock].iloc[i - self.window_stoa:i]

                # 检查是否有 NaN
                if np.isnan(turnover_window).all():
                    stoa_df.at[liquidity_df.index[i], stock] = np.nan
                else:
                    # 计算一个年度的换手率
                    stoa = np.log(turnover_window.sum() / 12)
                    stoa_df.at[liquidity_df.index[i], stock] = stoa

        return stoa_df

    def combine_liquidity(self, stom_df, stoq_df, stoa_df):
        """
        计算组合流动性因子。

        参数:
        - stom_df: DataFrame，STOM 数据。
        - stoq_df: DataFrame，STOQ 数据。
        - stoa_df: DataFrame，STOA 数据。

        返回:
        - combined_liquidity_df: DataFrame，组合流动性因子，index 和 columns 与输入保持一致。
        """
        combined_liquidity_df = 0.35 * stom_df + 0.35 * stoq_df + 0.30 * stoa_df
        return combined_liquidity_df

    def orthogonalize(self, factor_df, size_df):
        """
        将因子与 Beta 和 Size 正交化，以减少共线性。

        参数:
        - factor_df: DataFrame，待正交化的因子。
        - size_df: DataFrame，Size 因子。

        返回:
        - orthogonalized_factor_df: DataFrame，正交化后的因子。
        """
        orthogonalized_factor_df = pd.DataFrame(index=factor_df.index, columns=factor_df.columns)

        for date in factor_df.index:
            X = size_df.loc[date].values.reshape(-1, 1)
            y = factor_df.loc[date]

            valid_idx = ~np.isnan(X.flatten()) & ~np.isnan(y) & np.isfinite(X.flatten()) & np.isfinite(y)
            X_valid = X[valid_idx]
            y_valid = y[valid_idx]
            
            if len(X_valid) == 0:
                orthogonalized_factor_df.loc[date] = np.nan  # 该日期的残差设为 NaN
                continue

            if len(X_valid) > 0 and len(y_valid) > 0:
                model = LinearRegression()
                model.fit(X_valid, y_valid)
                residuals = y_valid - model.predict(X_valid)
                orthogonalized_factor_df.loc[date, residuals.index] = residuals

        return orthogonalized_factor_df

if __name__ == "__main__":
    # 初始化 LiquidityCalculator
    liquidity_calculator = LiquidityCalculator()
    
    stock_turnover_df = liquidity_calculator.stock_turnover()
    
    # # 计算 STOM
    # stom_df = liquidity_calculator.calculate_stom()
    # stom_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/stom.csv')

    # # 计算 STOQ
    # stoq_df = liquidity_calculator.calculate_stoq()
    # stoq_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/stoq.csv')

    # # 计算 STOA
    # stoa_df = liquidity_calculator.calculate_stoa()
    # stoa_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/stoa.csv')

    # 本地读取
    stom_df = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/stom.csv', index_col='TradingDay')
    stoq_df = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/stoq.csv', index_col='TradingDay')
    stoa_df = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/stoa.csv', index_col='TradingDay')
    # 计算组合流动性因子
    combined_liquidity_df = liquidity_calculator.combine_liquidity(stom_df, stoq_df, stoa_df)
    combined_liquidity_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/combined_liquidity.csv')
    
    # 读取 Size 数据
    size_df = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/log_cap.csv', index_col='TradingDay')
    orthogonalized_liquidity_df = liquidity_calculator.orthogonalize(combined_liquidity_df, size_df)
    orthogonalized_liquidity_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/liquidity.csv')
