import pandas as pd
import numpy as np

class MomentumCalculator:
    def __init__(self, daily_quotes):
        self.daily_quotes = daily_quotes

    def generate_ret_df(self):
        """
        生成一个以交易日期为索引，股票代码为列，值为收益率的DataFrame
        """
        self.daily_quotes['TradingDay'] = pd.to_datetime(self.daily_quotes['TradingDay'])
        self.daily_quotes.set_index('TradingDay', inplace=True)
        
        # 生成以交易日期为索引，股票代码为列，值为收益率的DataFrame
        ret_df = self.daily_quotes.pivot_table(values='ret', index=self.daily_quotes.index, columns='SecuCode')
        self.index = ret_df.index
        self.columns = ret_df.columns
        return ret_df

    def get_risk_free_rates(self, rate=0.0001):
        """
        获取无风险收益率（近似十年国债利率）
        """
        return pd.DataFrame(rate, index=self.index, columns=self.columns)

    def calculate_momentum(self, ret_df, risk_free_rates, T=504, L=21, half_life=126):
        """
        计算动量因子（时间降序排列）
        """
        # 计算超额收益率
        excess_returns = np.log1p(ret_df) - np.log1p(risk_free_rates)
        
        # 计算指数权重（时间降序排列）
        decay_factor = np.log(2) / half_life
        time_diff = np.arange(T + L)  # 从 0 到 T+L-1
        weights = np.exp(-decay_factor * time_diff)
        weights = weights / weights.sum()  # 归一化
        weights = weights[::-1]
        
        # 计算动量因子（RSTR）
        momentum = excess_returns.rolling(window=T + L, min_periods=1).apply(
            lambda x: np.sum(x * weights[:len(x)]), raw=True
        ).shift(L)  # 使用正滞后
        
        return momentum

if __name__ == '__main__':
    # 读取CSV文件
    daily_quotes = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/daily_quote_2010_2018_combined.csv')
    
    momentum_calculator = MomentumCalculator(daily_quotes)
    ret_df = momentum_calculator.generate_ret_df()
    ret_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/ret.csv')
    
    # 获取无风险收益率序列
    risk_free_rates = momentum_calculator.get_risk_free_rates(ret_df.index)
    
    # 计算动量因子
    momentum = momentum_calculator.calculate_momentum(ret_df, risk_free_rates)
    momentum_df = pd.DataFrame(momentum, index=ret_df.index, columns=ret_df.columns)
    # 保存结果到新的CSV文件
    momentum_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/momentum.csv')
    
    print(ret_df.head())