import pandas as pd

class IndustryFactorGenerator:
    def __init__(self, industry_data_path, ret_data_path):
        # 读取行业分类数据
        self.industry_data = pd.read_csv(industry_data_path)
        self.industry_data['InfoPublDate'] = pd.to_datetime(self.industry_data['InfoPublDate'])
        self.industry_data.sort_values(by=['SecuCode', 'InfoPublDate'], inplace=True)

        # 读取 ret 数据中的股票代码和日期
        self.ret_data = pd.read_csv(ret_data_path, index_col='TradingDay')
        self.index = self.ret_data.index
        self.stocks = self.ret_data.columns.astype(int)
        
        self.industry_mapping = {
            '银行': 1, '房地产': 2, '计算机': 3, '医药': 4, '电力及公用事业': 5, '餐饮旅游': 6, '有色金属': 7, 
            '商贸零售': 8, '交通运输': 9, '机械': 10, '综合': 11, '电子元器件': int(12), '建筑': 13, '建材': 14, 
            '家电': 15, '纺织服装': 16, '食品饮料': 17, '石油石化': 18, '汽车': 19, '轻工制造': 20, '通信': 21, 
            '农林牧渔': 22, '电力设备': 23, '传媒': 24, '基础化工': 25, '煤炭': 26, '非银行金融': 27, '钢铁': 28, 
            '国防军工': 29
        }

    def generate_industry_factors(self):
        """生成行业因子"""
        # 初始化结果 DataFrame
        industry_factors = pd.DataFrame(index=self.ret_data.index, columns=self.stocks)

        for stock in self.stocks:
            # 获取当前股票的行业变更记录
            stock_industry = self.industry_data[self.industry_data['SecuCode'] == stock]

            # 初始化行业标签
            industry_label = None

            # 遍历日期范围，为每一天分配行业标签
            for date in self.ret_data.index:
                # 查找当前日期之前的最后一条行业变更记录
                industry_record = stock_industry[stock_industry['InfoPublDate'] <= date]

                if not industry_record.empty:
                    industry_label = industry_record.iloc[-1]['tag']

                industry_factors.at[date, stock] = industry_label

        return industry_factors
    
    def replace_industry_names_with_codes(self, industry_factors):
        """将行业名称替换为编号"""
        industry_factors_replaced = industry_factors.replace(self.industry_mapping)
        industry_factors_replaced = industry_factors_replaced.applymap(lambda x: int(x) if pd.notnull(x) else x)
        return industry_factors_replaced
    
    def feature_matrix(self, industry_factors):
        """生成特征矩阵"""
        # 将行业因子转换为哑变量（one-hot encoding）
        feature_matrix = pd.get_dummies(industry_factors.stack()).unstack().fillna(0)
        return feature_matrix
    
if __name__ == "__main__":
    # 初始化 IndustryFactorGenerator
    industry_data_path = '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/industry.csv'
    ret_data_path = '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/ret.csv'
    industry_factor_generator = IndustryFactorGenerator(industry_data_path, ret_data_path)
    
    # # 生成行业因子
    # industry_factors = industry_factor_generator.generate_industry_factors()
    
    # # 保存结果
    # industry_factors.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/industry_factors.csv')
    
    industry_factors = pd.read_csv(
        '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/industry_factors.csv', 
        index_col='TradingDay', 
        dtype=str, 
        low_memory=False
    )
    
    industry_factors_numbered = industry_factor_generator.replace_industry_names_with_codes(industry_factors)
    
    industry_factors_numbered.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/industry_factors_numbered.csv')
    
    # 生成特征矩阵
    feature_matrix = industry_factor_generator.feature_matrix(industry_factors_numbered)
    
    # 保存特征矩阵结果
    feature_matrix.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/feature_matrix.csv')

    # 查看结果
    print(feature_matrix.tail())