import pandas as pd
import matplotlib.pyplot as plt

def plot_compound_returns(file_path, factor_name):
    # 读取数据
    df = pd.read_csv(file_path, index_col=0, parse_dates=True)
    
    # 检查因子名称是否存在
    if factor_name not in df.columns:
        raise ValueError(f"Factor '{factor_name}' not found in the data.")
    
    # 计算累计收益率
    cumulative_returns = (1 + df[factor_name]).cumprod() - 1
    
    # 绘制累计收益率
    plt.figure(figsize=(10, 6))
    plt.plot(cumulative_returns, label=factor_name)
    plt.xlabel('Date')
    plt.ylabel(f'Compound Cumulative Returns of {factor_name}')
    plt.title(f'Compound Cumulative Returns of {factor_name}')
    plt.legend()
    plt.grid(True)
    
    # 保存图片
    save_path = f'/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/graph/Compound Cumulative Returns of {factor_name}.png'
    plt.savefig(save_path)
    plt.show()
    
def plot_sum_returns(file_path, factor_name):
    # 读取数据
    df = pd.read_csv(file_path, index_col=0, parse_dates=True)
    
    # 检查因子名称是否存在
    if factor_name not in df.columns:
        raise ValueError(f"Factor '{factor_name}' not found in the data.")
    
    # 计算累计收益率
    cumulative_returns =  df[factor_name].cumsum()
    
    # 绘制累计收益率
    plt.figure(figsize=(10, 6))
    plt.plot(cumulative_returns, label=factor_name)
    plt.xlabel('Date')
    plt.ylabel(f'Sum Cumulative Returns of {factor_name}')
    plt.title(f'Sum Cumulative Returns of {factor_name}')
    plt.legend()
    plt.grid(True)
    
    # 保存图片
    save_path = f'/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/graph/Sum Cumulative Returns of {factor_name}.png'
    plt.savefig(save_path)
    plt.show()
    
file_path = '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/return_results_filtered.csv'
factor_list = ['Liquidity','Beta','LogCap','ResidualVol','TriCap','Momentum',]
for factor_name in factor_list:
    plot_compound_returns(file_path, factor_name)
    plot_sum_returns(file_path, factor_name)