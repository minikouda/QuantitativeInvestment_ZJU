import pandas as pd
import numpy as np

class Sigma:
    def __init__(self, lambda_value=0.94, half_life=42, window=252):
        self.lambda_value = lambda_value
        self.half_life = half_life
        self.window = window
    
    def calculate_ewma_covariance(self, factor_returns):
        """
        计算因子收益率的EWMA协方差矩阵
        :param factor_returns: 因子收益率数据（DataFrame，index为日期，columns为因子名称）
        :return: EWMA协方差矩阵
        """
        dates = factor_returns.index
        factors = factor_returns.columns
        n_factors = len(factors)
        
        lambda_ = np.log(2) / self.half_life
        weights = np.exp(-lambda_ * np.arange(self.window)[::-1])  # 指数权重
        weights /= weights.sum()  # 归一化权重

        # 初始化第一个协方差矩阵
        cov_matrix = np.cov(factor_returns.iloc[:252].T)
        cov_matrix_series = {dates[251]: pd.DataFrame(cov_matrix, index=factors, columns=factors)}
        
        window_length = self.window
        # 遍历每个时间点
        for t in range(window_length, len(dates)):
            # 获取当前时间窗口的数据
            window_data = factor_returns.iloc[t - window_length:t]

            # 计算加权协方差矩阵
            weighted_cov_matrix = np.zeros((n_factors, n_factors))
            for s in range(window_length):
                f_t = window_data.iloc[s].values.reshape(-1, 1)
                weighted_cov_matrix += weights[s] * np.dot(f_t, f_t.T)
                
            #删除最后一行最后一列
            weighted_cov_matrix = weighted_cov_matrix[:-1,:-1]
            # 保存协方差矩阵
            
            cov_matrix_series[dates[t]] = weighted_cov_matrix
        
        return cov_matrix_series
    
    def calculate_ewma_specific_risk(self,residuals):
        """
        计算每只股票的特定风险（使用 EWMA 方法）
        :param residuals: 残差数据（DataFrame，index 是日期，columns 是股票名称）
        :param tau: 衰减参数，用于计算 lambda
        :param window: EWMA 的样本长度
        :return: 特定风险矩阵（DataFrame，index 是日期，columns 是股票名称）
        """
        # 计算 lambda
        lambda_value = 0.5 ** (1 / self.half_life)
        window = self.window
        # 初始化特定风险矩阵
        specific_risk = pd.DataFrame(index=residuals.index, columns=residuals.columns)
        
        # 遍历每只股票
        for stock in residuals.columns:
            # 获取当前股票的残差数据
            stock_residuals = residuals[stock]
            
            # 初始化 EWMA 方差
            ewma_var = np.zeros_like(stock_residuals)
            
            # 计算 EWMA 方差
            for t in range(window, len(stock_residuals)):
                # 提取时间窗口内的残差数据
                window_data = stock_residuals.iloc[t - window:t]
                
                # 计算加权方差
                weights = np.array([lambda_value ** (t - s) for s in range(t - window, t)])
                weighted_var = np.sum(weights * (window_data - window_data.mean()) ** 2) / np.sum(weights)
                
                # 存储结果
                ewma_var[t] = weighted_var
            
            # 将 EWMA 方差赋值给特定风险矩阵
            specific_risk[stock] = ewma_var
        
        return specific_risk

    def adjust_covariance_matrix(self, factor_returns):
        """
        调整协方差矩阵
        :param factor_returns: 因子收益率 DataFrame
        :return: 调整后的协方差矩阵序列
        """
        dates = factor_returns.index
        adjusted_cov_matrix_series = {}

        # 计算 B_t^F
        btf_values_squared = self.calculate_btf(factor_returns)

        # 初始化协方差矩阵
        prev_cov_matrix = np.cov(factor_returns.iloc[:252].T)

        for t in range(252, len(dates)):
            r_t = factor_returns.iloc[t].values.reshape(-1, 1)
            ewma_cov_matrix = self.lambda_value * np.dot(r_t, r_t.T) + (1 - self.lambda_value) * prev_cov_matrix

            # 调整协方差矩阵：乘以 B_t^F
            btf_t = btf_values_squared.iloc[t]
            adjusted_cov_matrix = ewma_cov_matrix * btf_t

            # 保存调整后的协方差矩阵
            adjusted_cov_matrix_series[dates[t]] = adjusted_cov_matrix

            # 更新前一个协方差矩阵
            prev_cov_matrix = ewma_cov_matrix

        return adjusted_cov_matrix_series
    
    def calculate_btf(self, factor_returns):
        """
        计算因子截面偏差统计量 B_t^F
        :param factor_returns: 因子收益率数据（DataFrame，index为日期，columns为因子名称）
        :return: B_t^F 序列（Series，index为日期）
        """
        # 计算每个因子的历史波动率（标准差）
        historical_volatility = factor_returns.expanding().std()
        
        # 计算 B_t^F**2
        btf_values_squared = (1 / factor_returns.shape[1]) * ((factor_returns / historical_volatility) ** 2).sum(axis=1)
        
        return btf_values_squared
    
# 示例用法
if __name__ == "__main__":
    # 读取因子收益率数据
    factor_returns = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/return_results_filtered.csv', index_col=0, parse_dates=True)
    residual_barra = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/residual_barra.csv', index_col=0, parse_dates=True)

    # 初始化 Sigma 类
    sigma = Sigma()

    # 计算调整后的协方差矩阵
    calculated_cov_matrix_series = sigma.calculate_ewma_covariance(factor_returns)
    
    # # 计算特异性矩阵
    # specific_risk_matrices = sigma.calculate_ewma_specific_risk(residual_barra)
    # print(specific_risk_matrices)
    # # 保存结果到 CSV 文件
    # pd.DataFrame(specific_risk_matrices).to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/specific_risk_matrices.csv')

    # 输出结果
    # for date, cov_matrix in adjusted_cov_matrix_series.items():
    #     print(f"Date: {date}")
    #     print(cov_matrix)
    #     print()
        
    #     # 保存结果到 CSV 文件
    #     pd.DataFrame(cov_matrix).to_csv(f'/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/adjusted_cov_matrix.csv')
    
    
