import pandas as pd
import copy
import os
import numpy as np
import matplotlib.pyplot as plt
import connectorx as cx
from sqlalchemy import create_engine

plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
# plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签

class Analyze:
    '''计算指标或画图进行分析'''

    def evaluate_indicator(net_value,tradeday_per_year,anual_riskfree_rate):
        '''
        已知净值曲线之后进行各类指标的计算

        Parameters
        ----------
        net_value : pd.Series
            时间序列.
        anual_riskfree_rate : float
            年化无风险利率.
        tradeday_per_year：如果净值序列是月度的，那就取12；如果是日度的，就取250（每年的交易日数据）；如果是周度的，就取52（每年的周数）

        Returns
        -------
        annual_yield：年化收益率
        annual_std：每期收益率的年化标准差
        sharpe_ratio：年化收益率的夏普比率
        drawdown：回撤曲线
        max_drawdown：最大回撤

        '''
        net_value0 = copy.copy(net_value)

        net_value = np.array(net_value)
        len_nav = len(net_value)
        annual_yield = (net_value[-1]/net_value[0])**(tradeday_per_year/len_nav)-1

        yield_of_nav = net_value[1:]/net_value[0:-1]-1
        annual_std = np.std(yield_of_nav)*np.sqrt(tradeday_per_year)

        sharpe_ratio = (annual_yield-anual_riskfree_rate)/annual_std

        max_nv = net_value0.cummax()
        drawdown = (net_value0 - max_nv) / max_nv
        max_drawdown = np.max(-drawdown)

        # 分年度收益
        yield_year_last = net_value0.resample('y').last().pct_change()
        yield_year_first_to_last = net_value0.resample('y').last()/net_value0.resample('y').first()-1

        return annual_yield,annual_std,sharpe_ratio,drawdown,max_drawdown,yield_year_last,yield_year_first_to_last

    def evaluate_indicator_multi_asset(net_value,tradeday_per_year,anual_riskfree_rate):
        '''
        和evaluate_indicator区别是这里net_value是多资产的净值序列组成的dataframe

        Parameters
        ----------
        net_value : DataFrame
            DESCRIPTION.
        tradeday_per_year：如果净值序列是月度的，那就取12；如果是日度的，就取250（每年的交易日数据）；如果是周度的，就取52（每年的周数）
        anual_riskfree_rate : float
            0 or 0.03 ...

        Returns
        -------
        indicators : DataFrame
            DESCRIPTION.
        drawdowns : DataFrame
            DESCRIPTION.
        yield_year_lasts : DataFrame
            DESCRIPTION.
        yield_year_first_to_lasts : DataFrame
            DESCRIPTION.

        '''
        indicators = pd.DataFrame(index=net_value.columns,columns=['年化收益率','年化波动率','夏普比率','最大回撤'])
        drawdowns = []
        yield_year_lasts = []
        yield_year_first_to_lasts = []

        for code in net_value.columns:
            cur_nv = net_value[code]
            annual_yield,annual_std,sharpe_ratio,drawdown,max_drawdown,yield_year_last,yield_year_first_to_last = \
                Analyze.evaluate_indicator(cur_nv,tradeday_per_year,anual_riskfree_rate)
            indicators.loc[code,['年化收益率','年化波动率','夏普比率','最大回撤']] = [annual_yield,annual_std,sharpe_ratio,max_drawdown]

            drawdowns.append(drawdown)
            yield_year_lasts.append(yield_year_last)
            yield_year_first_to_lasts.append(yield_year_first_to_last)

        drawdowns = pd.concat(drawdowns,axis=1)
        yield_year_lasts = pd.concat(yield_year_lasts,axis=1)
        yield_year_first_to_lasts = pd.concat(yield_year_first_to_lasts,axis=1)

        return indicators,drawdowns,yield_year_lasts,yield_year_first_to_lasts

def Backtest_v3(target_weight,price_close,commission=0.003):
    '''
    简易回测

    Parameters
    ----------
    target_weight : dataframe
        index是调仓日，columns是资产，values是目标权重.
    price_close : dataframe
        index是日期（必须至少包含调仓日），columns是资产，values是价格一般是收盘价.
    commission : float,
        双边交易费率。默认双边千三即0.003

    Returns
    -------
    res : dict
        净值、年化收益等结果组成的dict.

    '''
    close = price_close.loc[target_weight.index,target_weight.columns]
    ret = close.pct_change()
    ret_weight = target_weight.shift(1)*ret
    ret_portfolio = ret_weight.sum(axis=1)
    nv_no_fee_prod = (1+ret_portfolio).cumprod()
    nv_no_fee = (ret_portfolio).cumsum()

    len_time = (target_weight.index[-1]-target_weight.index[0]).days/365
    tradeday_per_year = target_weight.shape[0]/len_time
    # annual_yield,annual_std,sharpe_ratio,drawdown,max_drawdown,yield_year_last,yield_year_first_to_last = Analyze.evaluate_indicator(nv_no_fee, tradeday_per_year=tradeday_per_year, anual_riskfree_rate=0)

    # # 换手率的估计其实非常粗略。因为即使两期的目标权重完全一致，也可能发生交易，但这么计算的话是没有交易费用的
    # # 交易费用是发生在实际价值（非权重）与目标价值之间
    # # 下面采取粗略的办法，只能计算年化收益和换手率而不输出曲线
    # turnover_double = (target_weight-target_weight.shift()).abs().sum(axis=1)
    # turnover_double_annual = turnover_double.sum()/len_time
    # single_commission = commission/2
    # annual_yield_after_fee = annual_yield-single_commission*turnover_double_annual

    # res = {'净值（不考虑交易费用）':nv_no_fee,
    #        '年化收益率':annual_yield,
    #        '年化波动率':annual_std,
    #        '夏普比率':sharpe_ratio,
    #        '回撤曲线':drawdown,
    #        '最大回撤':max_drawdown,
    #        '年化双边换手率':turnover_double_annual,
    #        '年化收益率（考虑交易费用）':annual_yield_after_fee}

    return nv_no_fee,nv_no_fee_prod


# 根据因子高低分成五组 分层回测
def get_tier(row):
    # 根据因子高低分成五组
    return pd.qcut(row.rank(method='first', ascending=False), q=5, labels=[1, 2, 3, 4, 5])

def get_weight(row, tier):
    # 计算当前tier所有股票的总数
    n = row.apply(lambda x: 1 if x == tier else 0).sum()
    # 计算平均分配权重
    return row.apply(lambda x: 1/n if x == tier else 0)


