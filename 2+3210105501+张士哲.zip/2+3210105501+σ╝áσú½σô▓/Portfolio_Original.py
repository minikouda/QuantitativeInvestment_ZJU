from Backtest import Analyze
from Backtest import Backtest_v3
from matplotlib import pyplot as plt
import pandas as pd
import numpy as np
import cvxpy as cp
import time
from functools import wraps

def timing_decorator(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"Function '{func.__name__}' executed in {elapsed_time:.4f} seconds")
        return result
    return wrapper

class Portfolio:
    def __init__(self, file_path, lambda_value=0.94):
        self.file_path = file_path
        self.lambda_value = lambda_value
        self.returns = self._load_data()
        self.weights = None

    def _load_data(self):
        """
        读取因子收益率数据
        """
        return pd.read_csv(self.file_path, index_col='TradingDay', parse_dates=True)

    def calculate_ewma_covariance(self, returns):
        """
        计算因子收益率的EWMA协方差矩阵
        :param returns: 因子收益率数据（DataFrame，index为日期，columns为因子名称）
        :return: EWMA协方差矩阵
        """
        cov_matrix = np.cov(returns.iloc[:252].T)
        for t in range(252, len(returns)):
            r_t = returns.iloc[t].values.reshape(-1, 1)
            cov_matrix = self.lambda_value * np.dot(r_t, r_t.T) + (1 - self.lambda_value) * cov_matrix
        # 确保协方差矩阵是对称的
        cov_matrix = (cov_matrix + cov_matrix.T) / 2
        return cov_matrix

    def filter_cov_matrix(self, cov_matrix):
        """
        筛选协方差矩阵中没有 NaN 的行和列
        :param cov_matrix: 协方差矩阵（DataFrame）
        :return: 筛选后的协方差矩阵
        """
        # 筛选出不全是 NaN 的行和列
        valid_indices = ~cov_matrix.isna().all(axis=1)
        filtered_cov_matrix = cov_matrix.loc[valid_indices, valid_indices]
        return filtered_cov_matrix

    @timing_decorator
    def original_return_rebalancing(self):
        """
        计算月度调仓
        """
        monthly_portfolios = {}
        # 获取每个月的最后一个交易日
        last_days = self.returns.groupby(self.returns.index.to_period('M')).apply(lambda x: x.index[-1])
        for end_of_month in last_days:
            if end_of_month.year < 2013:
                continue
            monthly_data = self.returns.loc[:end_of_month].iloc[-252:]

            # 计算EWMA协方差矩阵
            cov_matrix = self.calculate_ewma_covariance(monthly_data)
            cov_matrix = pd.DataFrame(cov_matrix, index=monthly_data.columns, columns=monthly_data.columns)

            # 筛选协方差矩阵中没有 NaN 的行和列
            cov_matrix = self.filter_cov_matrix(cov_matrix)

            # 筛选后的股票列表
            filtered_stocks = cov_matrix.columns

            # 定义优化变量
            n_assets = len(filtered_stocks)
            weights = cp.Variable(n_assets)

            # 定义目标函数（最小化风险）
            risk = cp.quad_form(weights, cov_matrix.values)
            objective = cp.Minimize(risk)

            # 定义约束条件
            constraints = [
                cp.sum(weights) == 1,  # 权重之和为1
                weights >= 0,  # 权重非负
                weights <= 0.01  # 单只股票权重不超过0.01
            ]

            # 定义并求解优化问题
            prob = cp.Problem(objective, constraints)
            prob.solve()

            # 获取最优权重
            optimal_weights = weights.value

            # 将最优权重映射回原始股票
            optimal_weights_full = pd.Series(0, index=self.returns.columns)
            optimal_weights_full[filtered_stocks] = optimal_weights

            monthly_portfolios[end_of_month] = optimal_weights_full

        # 转换为 DataFrame
        self.weights = pd.DataFrame.from_dict(monthly_portfolios, orient='index', columns=self.returns.columns)
        self.weights.index = pd.to_datetime(self.weights.index)
        self.weights.columns = self.weights.columns.astype(int)
        return self.weights

    def backtest(self, price_data, commission=0.003):
        """
        进行回测计算
        """
        if self.weights is None:
            raise ValueError("请先计算月度调仓权重")

        # 调用 Backtest_v3 函数进行回测
        nv_no_fee, nv_no_fee_prod = Backtest_v3(self.weights, price_data, commission)

        return nv_no_fee, nv_no_fee_prod

# 示例用法
if __name__ == "__main__":
    file_path = '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/ret.csv'
    portfolio = Portfolio(file_path)

    # 计算月度调仓
    weights = portfolio.original_return_rebalancing()

    # 读取股票价格数据
    quote= pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/daily_quote_2010_2018_combined.csv')
    price_data = quote.pivot_table(values='ClosePrice', index=quote['TradingDay'], columns='SecuCode')
    price_data.index = pd.to_datetime(price_data.index)

    # 进行回测计算
    nv_no_fee, nv_no_fee_prod = portfolio.backtest(price_data)

    
    # 绘制净值曲线
    plt.ioff()  # 关闭交互模式
    plt.figure(figsize=(10, 6))
    plt.plot(nv_no_fee, label='Sum Net Value (No Fee)(Original)')
    plt.xlabel('Date')
    plt.ylabel('Net Value')
    plt.title('Net Value Over Time(Original)')
    plt.legend()
    plt.grid(True)
    plt.ion()  # 重新打开交互模式
    plt.savefig('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/graph/Original_Sum_Return_Rebalancing.png')
    
    # 绘制净值曲线 （累乘）
    plt.figure(figsize=(10, 6))
    plt.plot(nv_no_fee_prod-1, label='Compound Net Value (No Fee)(Original)')
    plt.xlabel('Date')
    plt.ylabel('Net Value')
    plt.title('Compound Net Value Over Time(Original)')
    plt.legend()
    plt.grid(True)
    plt.savefig('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/graph/Original_Compound_Return_Rebalancing.png')