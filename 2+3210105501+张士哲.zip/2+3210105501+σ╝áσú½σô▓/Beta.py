import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

class BetaCalculator:
    def __init__(self, half_life=63, window=252):
        """
        初始化 BetaCalculator。

        参数:
        - half_life: int，指数权重的半衰期（默认 63 个交易日）。
        - window: int，回归窗口大小（默认 252 个交易日）。
        """
        self.half_life = half_life
        self.window = window
        
    def stock_return(self):
        self.stock = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/daily_quote_2010_2018_combined.csv')
        self.stock['TradingDay'] = pd.to_datetime(self.stock['TradingDay'])
        self.stock.set_index('TradingDay', inplace=True)
        
        stock_returns_df = self.stock.pivot_table(values='ret', index=self.stock.index, columns='SecuCode')
        return stock_returns_df
        

    def market_return(self):
        """
        读取市场收益率数据，并返回市场收益率的 DataFrame。
        """
        self.market = pd.read_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/daily_quote_2010_2018_combined.csv')
        self.market['TradingDay'] = pd.to_datetime(self.market['TradingDay'])
        self.market.set_index('TradingDay', inplace=True)

        market_returns_df = self.market.pivot_table(values='ZZ500Ret', index=self.market.index, columns='SecuCode')
        self.index = market_returns_df.index
        self.columns = market_returns_df.columns
        return market_returns_df

    def get_risk_free_rates(self, rate=0.0001):
        """
        获取无风险收益率（近似十年国债利率）
        """
        return pd.DataFrame(rate, index=self.index, columns=self.columns)
    
    def calculate_beta(self, stock_returns, market_returns, risk_free_rates):
        """
        计算每只股票的斜率系数 beta，并返回一个 DataFrame。

        参数:
        - stock_returns: DataFrame，每列是一只股票的收益率，index 是日期。
        - market_returns: Series，市场收益率，index 是日期。
        - risk_free_returns: float 或 Series，无风险收益率（默认 0.0001）。

        返回:
        - beta_df: DataFrame，每只股票的斜率系数 beta，index 和 columns 与输入保持一致。
        """
        # 计算超额收益
        stock_excess_returns = stock_returns - risk_free_rates  # 股票超额收益
        market_excess_returns = market_returns - risk_free_rates  # 市场超额收益

        # 定义指数权重
        lambda_ = np.log(2) / self.half_life
        weights = np.exp(-lambda_ * np.arange(self.window)[::-1])  # 指数权重

        # 初始化结果存储
        beta_df = pd.DataFrame(index=stock_returns.index, columns=stock_returns.columns)
        residual_df = pd.DataFrame(index=stock_returns.index, columns=stock_returns.columns)

        # 对每只股票进行滚动回归
        for stock in stock_returns.columns:
            for i in range(self.window, len(stock_returns)):
                # 获取滚动窗口内的数据
                X = market_excess_returns[stock].iloc[i - self.window:i].values.reshape(-1, 1)  # 使用 iloc 按位置索引
                y = stock_excess_returns[stock].iloc[i - self.window:i].values  # 使用 iloc 按位置索引
                if np.isnan(X).all() or np.isnan(y).all():
                    # 如果全部为 NaN，跳过当前窗口
                    continue
                elif np.isnan(X).any() or np.isnan(y).any():
                    # 如果有部分 NaN，用滚动窗口的均值填充
                    X = np.nan_to_num(X, nan=np.nanmean(X) if not np.isnan(X).all() else 0)
                    y = np.nan_to_num(y, nan=np.nanmean(y) if not np.isnan(y).all() else 0)
                # 加权回归
                model = LinearRegression()
                model.fit(X, y, sample_weight=weights)
                # 计算残差
                y_pred = model.predict(X)
                residuals = y - y_pred

                # 存储斜率系数 beta
                beta_df.at[stock_returns.index[i], stock] = model.coef_[0]
                # 存储残差（取最后一个残差值）
                residual_df.at[stock_returns.index[i], stock] = residuals[-1]

        return beta_df, residual_df
    
if __name__ == "__main__":
    # 初始化 BetaCalculator
    beta_calculator = BetaCalculator(half_life=63, window=252)
    
    stock_returns_df = beta_calculator.stock_return()
    market_returns_df = beta_calculator.market_return()
    risk_free_rates = beta_calculator.get_risk_free_rates()
    # 调用类方法
    beta_values , residual= beta_calculator.calculate_beta(stock_returns=stock_returns_df, market_returns= market_returns_df,risk_free_rates= risk_free_rates)
    beta_values.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/beta.csv')
    residual.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/beta_residual.csv')