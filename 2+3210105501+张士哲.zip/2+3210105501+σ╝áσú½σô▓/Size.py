import pandas as pd
import numpy as np
from Data_filter import StockPoolConstructor
from sklearn.linear_model import LinearRegression
from scipy.stats import zscore
from sklearn.impute import SimpleImputer

class SizeCalculator:
    def __init__(self, csv_file):
        self.data = pd.read_csv(csv_file)

    def generate_freefloatA_df(self):
        """
        生成一个以交易日期为索引，股票代码为列，值为流通市值（ClosePrice * AFloats）的DataFrame
        """
        df = self.data.copy()
        df['TradingDay'] = pd.to_datetime(df['TradingDay'])
        df.set_index('TradingDay', inplace=True)
        # 计算流通市值
        df['freefloatA'] = df['ClosePrice'] * df['AFloats']
        
        # 生成以交易日期为索引，股票代码为列，值为流通市值的DataFrame
        freefloatA_df = df.pivot_table(values='freefloatA', index= df.index, columns='SecuCode')
        
        return freefloatA_df

    def log_cap(self, freefloatA_df):
        """
        对流通市值数据取对数
        """
        log_freefloatA_df = np.log(freefloatA_df)
        return log_freefloatA_df

    def filter_stocks(self, freefloatA_df, stock_symbols):
        """
        过滤流通市值数据，只保留在指定股票代码集合中的股票
        """
        filtered_freefloatA_df = freefloatA_df[freefloatA_df.columns.intersection(stock_symbols)]
        return filtered_freefloatA_df

    def tri_orthogonalize(self,df):
        """
        对 df 进行1.标准化 2.立方 3.回归加权正交化，消除 Size 因子的线性影响。
        """
        df_standardized = df.apply(lambda x: zscore(x, nan_policy='omit'), axis=1)
        df_cubed = df_standardized ** 3
        df_orthogonalized = df_cubed.copy()
        
        for date in df_cubed.index:
            # 自变量：标准化的 Size 暴露
            X = df_standardized.loc[date].values.reshape(-1, 1)
            # 因变量：立方变换后的因子
            y = df_cubed.loc[date].values

            # 找到 X 和 y 都非 NaN 的索引
            valid_idx = ~np.isnan(X.flatten()) & ~np.isnan(y)
            X_valid = X[valid_idx]
            y_valid = y[valid_idx]

            # 如果没有有效数据，跳过该日期
            if len(X_valid) == 0:
                df_orthogonalized.loc[date] = np.nan  # 该日期的残差设为 NaN
                continue

            # 使用加权回归（这里权重为 1，可以根据需要调整）
            weights = np.ones_like(y_valid)
            model = LinearRegression()
            model.fit(X_valid, y_valid, sample_weight=weights)

            # 计算残差（正交化后的因子）
            y_pred = model.predict(X_valid)
            residuals = np.full_like(y, np.nan)  # 初始化残差为 NaN
            residuals[valid_idx] = y_valid - y_pred  # 填充有效位置的残差

            # 存储残差
            df_orthogonalized.loc[date] = residuals

        return df_orthogonalized
    

def winsorize(row, lower=0.01, upper=0.99):
    """
    对每一行进行 Winsorize 处理。
    :param row: 一行数据（Pandas Series）。
    :param lower: 下分位数（默认 1%）。
    :param upper: 上分位数（默认 99%）。
    :return: Winsorize 处理后的行数据。
    """
    lower_bound = row.quantile(lower)  # 计算下分位数
    upper_bound = row.quantile(upper)  # 计算上分位数
    return row.clip(lower_bound, upper_bound)  # 限制在分位数范围内

if __name__ == '__main__':
    # 读取CSV文件
    csv_file = '/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/daily_quote_2010_2018_combined.csv'
    
    # 初始化流通市值提取器
    extractor = SizeCalculator(csv_file)
    
    # 生成流通市值DataFrame，只保留2010-2018年的数据
    freefloatA_df = extractor.generate_freefloatA_df()
    
    # 对流通市值数据取对数
    log_freefloatA_df = extractor.log_cap(freefloatA_df)
    
    # 保存取对数后的数据
    log_freefloatA_df.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/log_cap.csv')
    
    df_orthogonalized = extractor.tri_orthogonalize(df = log_freefloatA_df)
    
    df_winsorized = df_orthogonalized.apply(winsorize, axis=1)
    df_standardized = df_winsorized.apply(lambda x: zscore(x, nan_policy='omit'), axis=1)
    
    df_standardized.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/tri_cap.csv')
