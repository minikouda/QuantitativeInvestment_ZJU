import pandas as pd

class StockPoolConstructor:
    def __init__(self, start_year, end_year):
        """
        初始化 StockPoolConstructor 类。
        """
        
        self.data = pd.read_parquet('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/指数权重/index_wt_000905.parquet')
        self.data['date'] = pd.to_datetime(self.data['date'])
        self.start_year = start_year
        self.end_year = end_year

    def get_stock_pool(self):
        """
        获取指定年份范围内的成分股列表。

        参数:
        start_year (int): 开始年份（例如 2010）。
        end_year (int): 结束年份（例如 2020）。

        返回:
        dict: 一个字典，键为年份，值为该年份的成分股列表。
        """

        # 筛选指定年份范围的数据
        df_filtered = self.data[
            (self.data['date'] >= pd.to_datetime(f'{self.start_year}-01-01')) &
            (self.data['date'] <= pd.to_datetime(f'{self.end_year}-12-31'))
        ]
        return df_filtered
    
    def filter_daily_quotes(self, daily_quotes):
        """
        筛选日线数据中股票代码在成分股池中的信息。

        参数:
        daily_quotes (DataFrame): 包含日线数据的DataFrame。

        返回:
        DataFrame: 筛选后的日线数据。
        """
        stock_pool = self.get_stock_pool()
        stock_pool_symbols = stock_pool['symbol'].unique()
        daily_quotes['SecuCode'] = daily_quotes['SecuCode'].astype(str)

        filtered_quotes = daily_quotes[daily_quotes['SecuCode'].isin(stock_pool_symbols)]
        return filtered_quotes


if __name__ == '__main__':
    constructor = StockPoolConstructor(2010, 2019)

    # 获取 2010 年到 2020 年的成分股列表
    stockpool = constructor.get_stock_pool()
    unique_number = stockpool['symbol'].unique()
    print(len(unique_number))
    stockpool.to_csv('project_2/Data_Barra/stockpool.csv')

    # 合并10年的CSV文件
    all_filtered_quotes = []

    for i in range(2010, 2019):
        daily_quotes = pd.read_csv(f'project_2/Data_Barra/日行情/daily_quote_{i}.csv')
        filtered_quotes = constructor.filter_daily_quotes(daily_quotes)
        all_filtered_quotes.append(filtered_quotes)
        print(f"Filtered quotes for {i} processed successfully.")

    # 将所有年份的数据合并在一起
    combined_filtered_quotes = pd.concat(all_filtered_quotes, ignore_index=True)
    combined_filtered_quotes.to_csv('project_2/Data_Barra/daily_quote_2010_2018_combined.csv', index=False)
    print("Combined filtered quotes saved successfully.")