import pandas as pd
import numpy as np
from scipy.stats import zscore
import statsmodels.api as sm

class DataProcessor:
    def __init__(self, limits=(0.01, 0.99)):
        self.limits = limits

    def winsorize_series(self, series):
        """
        对一个 Series 进行 winsorize 处理。
        """
        lower_limit = series.quantile(self.limits[0], interpolation='linear')
        upper_limit = series.quantile(self.limits[1], interpolation='linear')
        winsorized_series = series.clip(lower=lower_limit, upper=upper_limit)
        return winsorized_series

    def winsorize_df(self, df):
        """
        对一个 DataFrame 的每一行进行 winsorize 处理。
        """
        return df.apply(lambda row: self.winsorize_series(row), axis=1)
    
    def standardize_series(self, series):
        """
        对一个 Series 进行标准化处理（z-score），忽略空值。
        """
        return (series - series.mean(skipna=True)) / series.std(skipna=True)

    def standardize_df(self, df):
        """
        对一个 DataFrame 的每一行进行标准化处理（z-score），忽略空值。
        """
        return df.apply(lambda row: self.standardize_series(row), axis=1)

    def winsorize_and_standardize(self, df):
        """
        对一个 DataFrame 的每一行进行 winsorize 和标准化处理。
        """
        winsorized_df = self.winsorize_df(df)
        standardized_df = self.standardize_df(winsorized_df)
        print(f'{df} winsorize and standardize done')
        return standardized_df

def read_factor_data(factor_name):
    """
    读取指定因子的 CSV 文件，并返回相应的 DataFrame。
    """
    file_path = f'/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/{factor_name}.csv'
    factor_df = pd.read_csv(file_path, index_col='TradingDay')
    factor_df.index = pd.to_datetime(factor_df.index)
    return factor_df

# def transform_industry_factors(industry_factors_one_hot):
#     """将多级索引的行业因子转换为哑变量"""
#     # 提取行业代码
#     industry_codes = industry_factors_one_hot.columns.get_level_values(0).unique()
    
#     # 初始化结果 DataFrame
#     industry_dummies = pd.DataFrame(index=industry_factors_one_hot.index)
    
#     # 对每个行业代码生成哑变量
#     for code in industry_codes:
#         # 获取属于当前行业的所有股票
#         stocks_in_industry = industry_factors_one_hot[code]
        
#         # 对每只股票生成哑变量
#         industry_dummies[f'Industry_{int(code)}'] = stocks_in_industry.any(axis=1).astype(int)
    
#     return industry_dummies

class CrossSectionalRegression:
    def __init__(self, ret_df, liquidity_df, beta_df, industry_df, log_cap_df, residual_voli_df, tri_cap_df, momentum_df):
        self.ret_df = ret_df
        self.liquidity_df = liquidity_df
        self.beta_df = beta_df
        self.industry_df = industry_df
        self.log_cap_df = log_cap_df
        self.residual_voli_df = residual_voli_df
        self.tri_cap_df = tri_cap_df
        self.momentum_df = momentum_df

    def _transform_industry_factors(self, industry_df):
        """将行业因子转换为哑变量，并确保数据类型为 float"""
        # 初始化结果 DataFrame，index 是股票代码，columns 是行业代码
        industry_dummies = pd.DataFrame(index=industry_df.columns)

        # 获取所有行业代码
        industry_codes = industry_df.stack().dropna().unique()

        # 对每个行业代码生成哑变量
        for code in industry_codes:
            # 生成哑变量列，表示每只股票是否属于当前行业
            industry_dummies[f'Industry_{int(code)}'] = (industry_df == code).any(axis=0).astype(float)

        # 将 NaN 填充为 0
        industry_dummies = industry_dummies.fillna(0.0)

        return industry_dummies

    def run_regression(self):
        """运行横截面回归"""
        # 初始化结果 DataFrame
        regression_results = pd.DataFrame()
        residuals = pd.DataFrame()

        # 获取所有日期
        dates = self.ret_df.index

        for date in dates[252:]:
            # 获取当天的收益率和因子数据
            y = self.ret_df.loc[date]  # 收益率
            X_liquidity = self.liquidity_df.loc[date]  # 流动性因子
            X_beta = self.beta_df.loc[date]  # Beta 因子
            X_log_cap = self.log_cap_df.loc[date]  # 对数市值
            X_residual_voli = self.residual_voli_df.loc[date]  # 残差波动率
            X_tri_cap = self.tri_cap_df.loc[date]  # 非线形市值
            X_momentum = self.momentum_df.loc[date]  # 动量因子
            X_industry = self._transform_industry_factors(self.industry_df.loc[[date]])  # 行业哑变量

            # 拼接特征矩阵
            X = pd.concat([
                X_liquidity, 
                X_beta, 
                X_log_cap, 
                X_residual_voli, 
                X_tri_cap, 
                X_momentum, 
                X_industry
            ], axis=1)
                        
            X.columns = ['Liquidity', 'Beta', 'LogCap', 'ResidualVol', 'TriCap', 'Momentum'] + list(X_industry.columns)
            X.columns = X.columns.astype(str)

            # industry_cols = [col for col in X.columns if col.startswith('Industry_')]
            # X[industry_cols] = X[industry_cols].fillna(0)
            # X[industry_cols].to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/industry_factors_test.csv')  
            # 去除 NaN 值
            non_industry_cols = ['Liquidity', 'Beta', 'LogCap', 'ResidualVol', 'TriCap', 'Momentum']
            
            # 移除股票 601128 和 600908
            exclude_stocks = ['601128', '600908']
            X = X[~X.index.isin(exclude_stocks)]
            y = y[~y.index.isin(exclude_stocks)]
            
            valid_idx = y.dropna().index.intersection(X[non_industry_cols].dropna().index)
            y = y.loc[valid_idx]
            X = X.loc[valid_idx]

            if len(y) > 0 and len(X) > 0:
                
                model = sm.OLS(y, X)
                results = model.fit()

                results_df = pd.DataFrame(results.params).T
                results_df.index = [date] # 将日期作为索引
                regression_results = pd.concat([regression_results, results_df], axis=0)

                # 计算残差
                residuals_df = pd.DataFrame(results.resid, columns=[date]).T
                residuals_df.columns = valid_idx
                residuals = pd.concat([residuals, residuals_df], axis=0)

                print(f"Regression for date {date} done")
            else:
                print(f"No valid data for date {date}")




        return regression_results, residuals


# 示例用法
if __name__ == "__main__":
    # 初始化 DataProcessor
    data_processor = DataProcessor(limits=(0.01, 0.99))
    
    # 读取数据
    ret_df = read_factor_data('ret')
    log_cap_df = read_factor_data('log_cap')
    tri_cap_df = read_factor_data('tri_cap')
    beta_df = read_factor_data('beta')
    momentum_df = read_factor_data('momentum')
    liquidity_df = read_factor_data('liquidity')
    residual_voli_df = read_factor_data('residual_voli')
    industry_factors_df = read_factor_data('industry_factors_numbered')
    
    # 去极值和标准化
    log_cap_df = data_processor.winsorize_and_standardize(log_cap_df)
    tri_cap_df = data_processor.winsorize_and_standardize(tri_cap_df)
    beta_df = data_processor.winsorize_and_standardize(beta_df)
    momentum_df = data_processor.winsorize_and_standardize(momentum_df)
    liquidity_df = data_processor.winsorize_and_standardize(liquidity_df)
    residual_voli_df = data_processor.winsorize_and_standardize(residual_voli_df)
    
    # 初始化 CrossSectionalRegression
    csr = CrossSectionalRegression(ret_df, liquidity_df, beta_df, industry_factors_df, log_cap_df, residual_voli_df, tri_cap_df, momentum_df)
    
    # 运行回归
    csr,residual = csr.run_regression()
    csr.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/return_results_filtered.csv')
    residual.to_csv('/Users/zhangshizhe/workingfile/senior/量化投资/final_project/project_2/Data_Barra/residual_barra.csv')